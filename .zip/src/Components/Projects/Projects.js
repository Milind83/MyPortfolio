import React from 'react'

function Projects() {
  return (
    <div id="projects" >
      Projects
    </div>
  )
}

export default Projects
